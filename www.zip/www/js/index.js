function display()
{
    var x=document.getElementById("t1").ariaValueMax;
    document.getElementById("para1").innerHTML=""
}